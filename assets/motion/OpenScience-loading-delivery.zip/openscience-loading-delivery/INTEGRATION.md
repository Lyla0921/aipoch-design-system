# 前端集成建议

## 直接预览

用浏览器打开：

```text
openscience-loading.html
```

## 推荐尺寸

- Message thinking：`96px` 到 `140px`
- 页面级 loading：`160px` 到 `220px`
- 全屏过渡 loading：`220px` 到 `300px`

## React 集成思路

把 `openscience-loading.html` 中的动画脚本迁移为组件：

```tsx
export function OpenScienceLoader({ size = 128 }: { size?: number }) {
  return (
    <div style={{ width: size, height: size, position: "relative" }}>
      <canvas ref={canvasRef} style={{ position: "absolute", inset: "-50%", width: "200%", height: "200%" }} />
    </div>
  );
}
```

动画状态、`LOGO_DOTS`、`createParticles` 和 `draw` 函数可以直接从 `openscience-loading.html` 迁移。

## 产品使用建议

优先使用 Canvas 实时版本。它比 GIF 更清晰，也可以根据不同容器尺寸自动缩放。

## Thinking Indicator

`openscience-thinking-indicator.html` 是 message thinking 的小尺寸状态图标，不建议使用完整 OpenScience logo 缩小。小尺寸里应该保留“颗粒、呼吸、轻旋转”的品牌语言，而不是强求完整 logo 识别。

建议尺寸：

- message inline：`18px` 到 `22px`
- assistant bubble：`22px` 到 `28px`
- panel thinking：`28px` 到 `32px`

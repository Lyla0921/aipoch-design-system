# OpenScience Loading Animation

## 文件说明

- `openscience-loading.html`：最新版实时动画文件。当前 3D 空间扩散、向内聚合、干净 logo、顺时针旋转和呼吸感都在这个文件里。
- `openscience-thinking-indicator.html`：message thinking 小图标动画。参考小 spark 状态图标，不强行缩完整 logo，适合 18px 到 32px。
- `openscience-logo.svg`：OpenScience 原始点阵 logo。
- `openscience-loading-loop-previous.gif`：上一版导出的 GIF，仅作参考，不是最新 3D 空间扩散效果。
- `openscience-loading-loop-previous-transparent.webm`：上一版导出的透明 WebM，仅作参考，不是最新 3D 空间扩散效果。

## 推荐交付方式

把 `openscience-loading.html` 交给前端同事作为动画原型或直接抽取实现。它是纯 HTML/CSS/Canvas/JS，不依赖网络、不依赖 npm 包。

把 `openscience-thinking-indicator.html` 用作 chat message 里的 thinking 状态原型。它是纯 CSS/HTML，不依赖脚本，适合直接抽成 React/Vue 组件。

如果需要放进产品里，建议前端把 `openscience-loading.html` 里的 `<section class="loader-shell">`、`<canvas>` 和 `<script>` 中的动画逻辑抽成组件。

## 当前动效定义

- 背景透明，适合叠在黑色医学 AI 产品界面上。
- 扩散态为 3D 粒子点云，有前后层次、明暗和大小变化。
- 粒子向内汇聚，最终形成 OpenScience logo。
- 聚合完成后只显示干净 logo 点阵，不保留边缘碎点。
- logo 完成态有轻微顺时针旋转和呼吸缩放。

## 注意

当前最新版没有重新导出成 GIF/WebM，因为本机录帧工具被额度限制拦住了。需要最终视频/GIF 资产时，请以后以 `openscience-loading.html` 为源重新录制导出，不要使用 `previous` 文件作为最终版本。

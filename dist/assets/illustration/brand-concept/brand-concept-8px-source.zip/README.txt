AIPOCH / Brand concept / 8px

Original supplied SVG, PNG preview and source line art.
Open preview.html for an offline preview. usage.html shows HTML embedding.
No artwork-generation script was included in the handoff.
SVG artwork is preserved unchanged.
